import React, { useState } from 'react';
import { useAppContext } from '../App';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Badge } from '../components/ui/badge';
import { Separator } from '../components/ui/separator';
import { 
  User, 
  Upload, 
  Plus, 
  FileText, 
  Calendar, 
  Pill, 
  IdCard,
  Clock
} from 'lucide-react';

const UserDashboard = () => {
  const { currentUser, language, consultations, receipts, setReceipts } = useAppContext();
  const [activeTab, setActiveTab] = useState('profile');
  const [newMedicine, setNewMedicine] = useState({
    name: '',
    dose: '',
    duration: ''
  });
  const [uploadedFile, setUploadedFile] = useState(null);

  const tabs = {
    en: [
      { key: 'profile', label: 'Profile', icon: User },
      { key: 'medicines', label: 'Medicines', icon: Pill },
      { key: 'consultations', label: 'Consultations', icon: FileText },
      { key: 'receipts', label: 'Receipts', icon: Upload }
    ],
    hi: [
      { key: 'profile', label: 'प्रोफाइल', icon: User },
      { key: 'medicines', label: 'दवाएं', icon: Pill },
      { key: 'consultations', label: 'परामर्श', icon: FileText },
      { key: 'receipts', label: 'रसीदें', icon: Upload }
    ]
  };

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const newReceipt = {
        id: Date.now(),
        name: file.name,
        uploadDate: new Date(),
        file: file
      };
      setReceipts(prev => [...prev, newReceipt]);
      setUploadedFile(file);
      alert(language === 'en' ? 'Receipt uploaded successfully!' : 'रसीद सफलतापूर्वक अपलोड की गई!');
    }
  };

  const handleAddMedicine = () => {
    if (newMedicine.name && newMedicine.dose) {
      // In a real app, this would be saved to backend
      alert(language === 'en' ? 'Medicine added successfully!' : 'दवा सफलतापूर्वक जोड़ी गई!');
      setNewMedicine({ name: '', dose: '', duration: '' });
    }
  };

  const userConsultations = consultations.filter(c => c.patientId === currentUser?.id);

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-6xl">
        {/* Welcome Header */}
        <div className="mb-8">
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-800">
                  {language === 'en' ? 'Welcome back' : 'वापस स्वागत है'}, {currentUser?.name}
                </h1>
                <div className="flex items-center space-x-4 mt-2">
                  <div className="flex items-center space-x-2">
                    <IdCard className="w-4 h-4 text-blue-600" />
                    <span className="text-sm text-gray-600">
                      {language === 'en' ? 'Health ID' : 'स्वास्थ्य आईडी'}: {currentUser?.healthId}
                    </span>
                  </div>
                  <Badge variant="secondary">
                    {language === 'en' ? 'Active Patient' : 'सक्रिय मरीज़'}
                  </Badge>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-600">
                  {language === 'en' ? 'Member since' : 'सदस्य बने'}
                </p>
                <p className="font-medium">
                  {new Date(currentUser?.createdAt).toLocaleDateString()}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="mb-6">
          <div className="bg-white rounded-lg shadow-sm p-1">
            <div className="flex space-x-1">
              {tabs[language].map((tab) => {
                const IconComponent = tab.icon;
                return (
                  <button
                    key={tab.key}
                    onClick={() => setActiveTab(tab.key)}
                    className={`flex items-center space-x-2 px-4 py-3 rounded-md font-medium transition-colors ${
                      activeTab === tab.key
                        ? 'bg-blue-600 text-white'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <IconComponent className="w-4 h-4" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Tab Content */}
        <div className="space-y-6">
          {activeTab === 'profile' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <User className="w-5 h-5" />
                  <span>{language === 'en' ? 'Personal Information' : 'व्यक्तिगत जानकारी'}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label className="text-sm font-medium text-gray-600">
                      {language === 'en' ? 'Full Name' : 'पूरा नाम'}
                    </Label>
                    <p className="text-lg font-medium">{currentUser?.name}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-600">
                      {language === 'en' ? 'Age' : 'आयु'}
                    </Label>
                    <p className="text-lg font-medium">{currentUser?.age} years</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-600">
                      {language === 'en' ? 'Gender' : 'लिंग'}
                    </Label>
                    <p className="text-lg font-medium">{currentUser?.gender}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-600">
                      {language === 'en' ? 'Hometown' : 'गृहनगर'}
                    </Label>
                    <p className="text-lg font-medium">{currentUser?.hometown}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-600">
                      {language === 'en' ? 'Profession' : 'पेशा'}
                    </Label>
                    <p className="text-lg font-medium">{currentUser?.profession}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-600">
                      {language === 'en' ? 'Chronic Disease' : 'पुरानी बीमारी'}
                    </Label>
                    <p className="text-lg font-medium">{currentUser?.chronicDisease || 'None'}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {activeTab === 'medicines' && (
            <div className="space-y-6">
              {/* Add Medicine Form */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Plus className="w-5 h-5" />
                    <span>{language === 'en' ? 'Add New Medicine' : 'नई दवा जोड़ें'}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-4 mb-4">
                    <div>
                      <Label htmlFor="medicineName">
                        {language === 'en' ? 'Medicine Name' : 'दवा का नाम'}
                      </Label>
                      <Input
                        id="medicineName"
                        value={newMedicine.name}
                        onChange={(e) => setNewMedicine(prev => ({ ...prev, name: e.target.value }))}
                        placeholder={language === 'en' ? 'Enter medicine name' : 'दवा का नाम दर्ज करें'}
                      />
                    </div>
                    <div>
                      <Label htmlFor="dose">
                        {language === 'en' ? 'Dosage' : 'खुराक'}
                      </Label>
                      <Input
                        id="dose"
                        value={newMedicine.dose}
                        onChange={(e) => setNewMedicine(prev => ({ ...prev, dose: e.target.value }))}
                        placeholder={language === 'en' ? 'e.g., 1 tablet' : 'जैसे 1 गोली'}
                      />
                    </div>
                    <div>
                      <Label htmlFor="duration">
                        {language === 'en' ? 'Duration' : 'अवधि'}
                      </Label>
                      <Input
                        id="duration"
                        value={newMedicine.duration}
                        onChange={(e) => setNewMedicine(prev => ({ ...prev, duration: e.target.value }))}
                        placeholder={language === 'en' ? 'e.g., 7 days' : 'जैसे 7 दिन'}
                      />
                    </div>
                  </div>
                  <Button onClick={handleAddMedicine} className="bg-green-600 hover:bg-green-700">
                    <Plus className="w-4 h-4 mr-2" />
                    {language === 'en' ? 'Add Medicine' : 'दवा जोड़ें'}
                  </Button>
                </CardContent>
              </Card>

              {/* Current Medicines */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Pill className="w-5 h-5" />
                    <span>{language === 'en' ? 'Current Medications' : 'वर्तमान दवाएं'}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    {currentUser?.currentMedications || (language === 'en' ? 'No medications listed' : 'कोई दवा सूचीबद्ध नहीं')}
                  </p>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === 'consultations' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <FileText className="w-5 h-5" />
                  <span>{language === 'en' ? 'Past Consultations' : 'पिछले परामर्श'}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {userConsultations.length > 0 ? (
                  <div className="space-y-4">
                    {userConsultations.map((consultation) => (
                      <div key={consultation.id} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <Badge variant="secondary">
                            {consultation.status}
                          </Badge>
                          <div className="flex items-center space-x-1 text-sm text-gray-600">
                            <Calendar className="w-4 h-4" />
                            <span>{new Date(consultation.date).toLocaleDateString()}</span>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <div>
                            <span className="font-medium text-gray-700">
                              {language === 'en' ? 'Symptoms:' : 'लक्षण:'}
                            </span>
                            <p className="text-gray-600">{consultation.symptoms}</p>
                          </div>
                          <div>
                            <span className="font-medium text-gray-700">
                              {language === 'en' ? 'Diagnosis:' : 'निदान:'}
                            </span>
                            <p className="text-gray-600">{consultation.diagnosis}</p>
                          </div>
                          <div>
                            <span className="font-medium text-gray-700">
                              {language === 'en' ? 'Prescription:' : 'नुस्खे:'}
                            </span>
                            <p className="text-gray-600">{consultation.prescription}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-600 text-center py-8">
                    {language === 'en' ? 'No consultations yet' : 'अभी तक कोई परामर्श नहीं'}
                  </p>
                )}
              </CardContent>
            </Card>
          )}

          {activeTab === 'receipts' && (
            <div className="space-y-6">
              {/* Upload Receipt */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Upload className="w-5 h-5" />
                    <span>{language === 'en' ? 'Upload Medicine Receipt' : 'दवा की रसीद अपलोड करें'}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                    <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600 mb-4">
                      {language === 'en' 
                        ? 'Drag and drop your receipt or click to browse'
                        : 'अपनी रसीद को खींचें और छोड़ें या ब्राउज़ करने के लिए क्लिक करें'
                      }
                    </p>
                    <input
                      type="file"
                      accept="image/*,.pdf"
                      onChange={handleFileUpload}
                      className="hidden"
                      id="receiptUpload"
                    />
                    <Button asChild className="bg-blue-600 hover:bg-blue-700">
                      <label htmlFor="receiptUpload" className="cursor-pointer">
                        {language === 'en' ? 'Choose File' : 'फ़ाइल चुनें'}
                      </label>
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Receipt History */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <FileText className="w-5 h-5" />
                    <span>{language === 'en' ? 'Uploaded Receipts' : 'अपलोड की गई रसीदें'}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {receipts.length > 0 ? (
                    <div className="space-y-3">
                      {receipts.map((receipt) => (
                        <div key={receipt.id} className="flex items-center justify-between p-3 border rounded-lg">
                          <div className="flex items-center space-x-3">
                            <FileText className="w-5 h-5 text-blue-600" />
                            <div>
                              <p className="font-medium">{receipt.name}</p>
                              <div className="flex items-center space-x-1 text-sm text-gray-600">
                                <Clock className="w-3 h-3" />
                                <span>{new Date(receipt.uploadDate).toLocaleDateString()}</span>
                              </div>
                            </div>
                          </div>
                          <Badge variant="secondary">
                            {language === 'en' ? 'Uploaded' : 'अपलोड किया गया'}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-600 text-center py-8">
                      {language === 'en' ? 'No receipts uploaded yet' : 'अभी तक कोई रसीद अपलोड नहीं की गई'}
                    </p>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default UserDashboard;