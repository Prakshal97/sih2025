import React, { useState, useMemo } from 'react';
import { useAppContext } from '../App';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { 
  Users, 
  Stethoscope, 
  FileText, 
  TrendingUp,
  BarChart3,
  Activity,
  MapPin,
  Calendar,
  User,
  PieChart,
  LineChart as LineChartIcon,
  Upload
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Area,
  AreaChart
} from 'recharts';

const AdminDashboard = () => {
  const { language, users, doctors, consultations, receipts } = useAppContext();
  const { diseases, analytics } = require('../data/mockData').mockData;

  // Chart colors
  const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#06B6D4'];
  const GRADIENT_COLORS = {
    primary: '#3B82F6',
    secondary: '#10B981',
    accent: '#F59E0B',
    danger: '#EF4444',
    purple: '#8B5CF6'
  };

  // Calculate real-time analytics
  const currentAnalytics = useMemo(() => {
    const today = new Date();
    const thisMonth = today.getMonth();
    const thisYear = today.getFullYear();

    const thisMonthUsers = users.filter(user => {
      const userDate = new Date(user.createdAt);
      return userDate.getMonth() === thisMonth && userDate.getFullYear() === thisYear;
    });

    const thisMonthConsultations = consultations.filter(consultation => {
      const consultDate = new Date(consultation.date);
      return consultDate.getMonth() === thisMonth && consultDate.getFullYear() === thisYear;
    });

    return {
      totalUsers: analytics.totalPatients,
      totalDoctors: analytics.totalDoctors,
      totalConsultations: analytics.totalConsultations,
      totalReceipts: analytics.receiptsUploaded,
      thisMonthUsers: thisMonthUsers.length || 1320,
      thisMonthConsultations: thisMonthConsultations.length || 1080
    };
  }, [users, doctors, consultations, receipts, analytics]);

  // Disease statistics by state
  const diseaseStats = useMemo(() => {
    const stateStats = {};
    diseases.forEach(item => {
      if (!stateStats[item.state]) {
        stateStats[item.state] = {};
      }
      stateStats[item.state][item.disease] = item.cases;
    });
    return stateStats;
  }, [diseases]);

  const tabs = {
    en: [
      { key: 'overview', label: 'Overview', icon: TrendingUp },
      { key: 'analytics', label: 'Analytics', icon: BarChart3 },
      { key: 'charts', label: 'Charts', icon: PieChart },
      { key: 'users', label: 'Users', icon: Users },
      { key: 'doctors', label: 'Doctors', icon: Stethoscope }
    ],
    hi: [
      { key: 'overview', label: 'अवलोकन', icon: TrendingUp },
      { key: 'analytics', label: 'विश्लेषण', icon: BarChart3 },
      { key: 'charts', label: 'चार्ट', icon: PieChart },
      { key: 'users', label: 'उपयोगकर्ता', icon: Users },
      { key: 'doctors', label: 'डॉक्टर', icon: Stethoscope }
    ]
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 py-8 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-72 h-72 bg-blue-200 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-72 h-72 bg-purple-200 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse delay-1000"></div>
      </div>

      <div className="container mx-auto px-4 max-w-7xl relative z-10">
        {/* Enhanced Header */}
        <div className="mb-10">
          <div className="bg-white/70 backdrop-blur-lg rounded-3xl shadow-2xl p-8 border border-white/20">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-gray-800 to-blue-800 bg-clip-text text-transparent mb-2">
                  {language === 'en' ? 'Admin Dashboard' : 'प्रशासक डैशबोर्ड'}
                </h1>
                <p className="text-xl text-gray-600">
                  {language === 'en' 
                    ? 'Real-time healthcare system monitoring & analytics'
                    : 'रियल-टाइम स्वास्थ्य सेवा प्रणाली निगरानी और विश्लेषण'
                  }
                </p>
              </div>
              <div className="flex items-center space-x-4">
                <div className="text-center">
                  <div className="w-4 h-4 bg-green-400 rounded-full mx-auto mb-2 animate-pulse"></div>
                  <p className="text-sm font-medium text-gray-700">System Online</p>
                </div>
                <div className="text-center">
                  <div className="w-4 h-4 bg-blue-400 rounded-full mx-auto mb-2 animate-pulse"></div>
                  <p className="text-sm font-medium text-gray-700">Real-time Data</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <Tabs defaultValue="overview" className="space-y-8">
          <TabsList className="grid w-full grid-cols-5 bg-white/70 backdrop-blur-lg rounded-2xl p-2 shadow-xl border border-white/20">
            {tabs[language].map((tab) => {
              const IconComponent = tab.icon;
              return (
                <TabsTrigger 
                  key={tab.key} 
                  value={tab.key} 
                  className="flex items-center space-x-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-indigo-600 data-[state=active]:text-white rounded-xl py-3"
                >
                  <IconComponent className="w-4 h-4" />
                  <span className="font-medium">{tab.label}</span>
                </TabsTrigger>
              );
            })}
          </TabsList>

          <TabsContent value="overview" className="space-y-8">
            {/* Enhanced Stats Cards */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-0 shadow-xl">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-gray-700">
                    {language === 'en' ? 'Total Patients' : 'कुल मरीज़'}
                  </CardTitle>
                  <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center">
                    <Users className="h-5 w-5 text-white" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-gray-800">{currentAnalytics.totalUsers.toLocaleString()}</div>
                  <p className="text-sm text-green-600 font-medium">
                    +{currentAnalytics.thisMonthUsers.toLocaleString()} {language === 'en' ? 'this month' : 'इस महीने'}
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-0 shadow-xl">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-gray-700">
                    {language === 'en' ? 'Active Doctors' : 'सक्रिय डॉक्टर'}
                  </CardTitle>
                  <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl flex items-center justify-center">
                    <Stethoscope className="h-5 w-5 text-white" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-gray-800">{currentAnalytics.totalDoctors.toLocaleString()}</div>
                  <p className="text-sm text-gray-600">
                    {language === 'en' ? 'Verified specialists' : 'सत्यापित विशेषज्ञ'}
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-0 shadow-xl">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-gray-700">
                    {language === 'en' ? 'Consultations' : 'परामर्श'}
                  </CardTitle>
                  <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-600 rounded-xl flex items-center justify-center">
                    <FileText className="h-5 w-5 text-white" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-gray-800">{currentAnalytics.totalConsultations.toLocaleString()}</div>
                  <p className="text-sm text-green-600 font-medium">
                    +{currentAnalytics.thisMonthConsultations.toLocaleString()} {language === 'en' ? 'this month' : 'इस महीने'}
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-orange-50 to-red-50 border-0 shadow-xl">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-gray-700">
                    {language === 'en' ? 'Receipts Uploaded' : 'अपलोड की गई रसीदें'}
                  </CardTitle>
                  <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl flex items-center justify-center">
                    <Upload className="h-5 w-5 text-white" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-gray-800">{currentAnalytics.totalReceipts.toLocaleString()}</div>
                  <p className="text-sm text-gray-600">
                    {language === 'en' ? 'Digital receipts' : 'डिजिटल रसीदें'}
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* State-wise Patient Growth */}
            <div className="grid md:grid-cols-2 gap-8">
              <Card className="bg-white/70 backdrop-blur-lg border-0 shadow-2xl">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingUp className="w-5 h-5 text-blue-600" />
                    <span>{language === 'en' ? 'State-wise Patient Growth' : 'राज्यवार मरीज़ वृद्धि'}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={analytics.stateWisePatients}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="state" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="patients" fill={GRADIENT_COLORS.primary} radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="bg-white/70 backdrop-blur-lg border-0 shadow-2xl">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Users className="w-5 h-5 text-green-600" />
                    <span>{language === 'en' ? 'Age Distribution' : 'आयु वितरण'}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <RechartsPieChart>
                      <Pie
                        data={analytics.ageDistribution}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={5}
                        dataKey="patients"
                        label={({ ageGroup, percentage }) => `${ageGroup}: ${percentage}%`}
                      >
                        {analytics.ageDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </RechartsPieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Enhanced Disease Distribution with Kerala */}
            <Card className="bg-white/70 backdrop-blur-lg border-0 shadow-2xl">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <MapPin className="w-5 h-5 text-purple-600" />
                  <span>{language === 'en' ? 'Disease Distribution by State (Including Kerala)' : 'राज्य के अनुसार रोग वितरण (केरल सहित)'}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid lg:grid-cols-2 gap-6">
                  {Object.entries(diseaseStats).map(([state, diseases]) => (
                    <div key={state} className={`rounded-2xl p-6 ${state === 'Kerala' ? 'bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-200' : 'bg-gradient-to-br from-gray-50 to-blue-50'}`}>
                      <div className="flex items-center justify-between mb-4">
                        <h4 className="font-bold text-xl text-gray-800">{state}</h4>
                        {state === 'Kerala' && (
                          <Badge className="bg-green-600 text-white">New Data</Badge>
                        )}
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        {Object.entries(diseases).map(([disease, cases]) => (
                          <div key={disease} className="bg-white/80 backdrop-blur-sm rounded-lg p-4 shadow-lg">
                            <div className="text-sm font-medium text-gray-600 mb-1">{disease}</div>
                            <div className="text-2xl font-bold text-blue-600">{cases.toLocaleString()}</div>
                            <div className="text-xs text-gray-500">
                              {language === 'en' ? 'cases' : 'मामले'}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="charts" className="space-y-8">
            {/* Monthly Trends Chart */}
            <Card className="bg-white/70 backdrop-blur-lg border-0 shadow-2xl">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <LineChartIcon className="w-5 h-5 text-blue-600" />
                  <span>{language === 'en' ? 'Monthly Healthcare Trends' : 'मासिक स्वास्थ्य सेवा रुझान'}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <LineChart data={analytics.monthlyStats}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="patients" 
                      stroke={GRADIENT_COLORS.primary} 
                      strokeWidth={3}
                      dot={{ fill: GRADIENT_COLORS.primary }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="consultations" 
                      stroke={GRADIENT_COLORS.secondary} 
                      strokeWidth={3}
                      dot={{ fill: GRADIENT_COLORS.secondary }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="receipts" 
                      stroke={GRADIENT_COLORS.accent} 
                      strokeWidth={3}
                      dot={{ fill: GRADIENT_COLORS.accent }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Disease Categories Analysis */}
            <div className="grid lg:grid-cols-2 gap-8">
              <Card className="bg-white/70 backdrop-blur-lg border-0 shadow-2xl">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <PieChart className="w-5 h-5 text-purple-600" />
                    <span>{language === 'en' ? 'Disease Categories' : 'रोग श्रेणियां'}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={350}>
                    <RechartsPieChart>
                      <Pie
                        data={analytics.diseaseCategories}
                        cx="50%"
                        cy="50%"
                        outerRadius={120}
                        dataKey="cases"
                        label={({ category, percentage }) => `${category}: ${percentage}%`}
                      >
                        {analytics.diseaseCategories.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </RechartsPieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="bg-white/70 backdrop-blur-lg border-0 shadow-2xl">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <BarChart3 className="w-5 h-5 text-green-600" />
                    <span>{language === 'en' ? 'Patient Growth by State' : 'राज्य के अनुसार मरीज़ वृद्धि'}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={350}>
                    <AreaChart data={analytics.stateWisePatients}>
                      <defs>
                        <linearGradient id="colorGrowth" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor={GRADIENT_COLORS.secondary} stopOpacity={0.8}/>
                          <stop offset="95%" stopColor={GRADIENT_COLORS.secondary} stopOpacity={0.1}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="state" />
                      <YAxis />
                      <Tooltip />
                      <Area 
                        type="monotone" 
                        dataKey="growth" 
                        stroke={GRADIENT_COLORS.secondary} 
                        fillOpacity={1} 
                        fill="url(#colorGrowth)" 
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Kerala Special Focus */}
            <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-200 shadow-2xl">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <MapPin className="w-5 h-5 text-green-600" />
                  <span className="text-green-800">{language === 'en' ? 'Kerala Healthcare Analytics' : 'केरल स्वास्थ्य सेवा विश्लेषण'}</span>
                  <Badge className="bg-green-600 text-white">Featured State</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl mx-auto mb-4 flex items-center justify-center">
                      <Users className="w-8 h-8 text-white" />
                    </div>
                    <h4 className="font-bold text-2xl text-gray-800">2,670</h4>
                    <p className="text-green-600 font-medium">Active Patients</p>
                    <p className="text-sm text-gray-600">+22% growth rate</p>
                  </div>
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-2xl mx-auto mb-4 flex items-center justify-center">
                      <Activity className="w-8 h-8 text-white" />
                    </div>
                    <h4 className="font-bold text-2xl text-gray-800">4,950</h4>
                    <p className="text-blue-600 font-medium">Total Cases</p>
                    <p className="text-sm text-gray-600">All disease categories</p>
                  </div>
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-600 rounded-2xl mx-auto mb-4 flex items-center justify-center">
                      <TrendingUp className="w-8 h-8 text-white" />
                    </div>
                    <h4 className="font-bold text-2xl text-gray-800">98.5%</h4>
                    <p className="text-purple-600 font-medium">Recovery Rate</p>
                    <p className="text-sm text-gray-600">Above national average</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Users className="w-5 h-5" />
                  <span>{language === 'en' ? 'Registered Patients' : 'पंजीकृत मरीज़'}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {users.length > 0 ? (
                  <div className="space-y-4">
                    {users.map((user) => (
                      <div key={user.id} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                              <User className="w-5 h-5 text-blue-600" />
                            </div>
                            <div>
                              <h4 className="font-medium">{user.name}</h4>
                              <p className="text-sm text-gray-600">
                                {user.age} {language === 'en' ? 'years' : 'साल'} • {user.gender} • {user.hometown}
                              </p>
                              <p className="text-xs text-gray-500">
                                {language === 'en' ? 'Health ID:' : 'स्वास्थ्य आईडी:'} {user.healthId}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="flex items-center space-x-1 text-sm text-gray-600 mb-1">
                              <Calendar className="w-3 h-3" />
                              <span>{new Date(user.createdAt).toLocaleDateString()}</span>
                            </div>
                            {user.chronicDisease && (
                              <Badge variant="outline" className="text-xs">
                                {user.chronicDisease}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-gray-600 py-8">
                    {language === 'en' ? 'No patients registered yet' : 'अभी तक कोई मरीज़ पंजीकृत नहीं'}
                  </p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="doctors" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Stethoscope className="w-5 h-5" />
                  <span>{language === 'en' ? 'Medical Professionals' : 'चिकित्सा पेशेवर'}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {doctors.length > 0 ? (
                  <div className="space-y-4">
                    {doctors.map((doctor) => (
                      <div key={doctor.id} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                              <Stethoscope className="w-5 h-5 text-green-600" />
                            </div>
                            <div>
                              <h4 className="font-medium">{doctor.name}</h4>
                              <p className="text-sm text-gray-600">
                                {doctor.specialty} • {doctor.experience} {language === 'en' ? 'years experience' : 'साल का अनुभव'}
                              </p>
                              <p className="text-xs text-gray-500">
                                {language === 'en' ? 'Registration:' : 'पंजीकरण:'} {doctor.registrationNo}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="flex items-center space-x-1 text-sm text-gray-600 mb-1">
                              <Calendar className="w-3 h-3" />
                              <span>{new Date(doctor.createdAt).toLocaleDateString()}</span>
                            </div>
                            <Badge variant="secondary" className="text-xs">
                              {language === 'en' ? 'Active' : 'सक्रिय'}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-gray-600 py-8">
                    {language === 'en' ? 'No doctors registered yet' : 'अभी तक कोई डॉक्टर पंजीकृत नहीं'}
                  </p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-8">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Enhanced System Metrics */}
              <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-0 shadow-xl">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <BarChart3 className="w-5 h-5 text-blue-600" />
                    <span>{language === 'en' ? 'Performance Metrics' : 'प्रदर्शन मेट्रिक्स'}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">
                        {language === 'en' ? 'Monthly Growth' : 'मासिक वृद्धि'}
                      </span>
                      <div className="text-right">
                        <span className="text-2xl font-bold text-blue-600">+15.3%</span>
                        <p className="text-xs text-gray-600">vs last month</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">
                        {language === 'en' ? 'Avg Response Time' : 'औसत प्रतिक्रिया समय'}
                      </span>
                      <div className="text-right">
                        <span className="text-2xl font-bold text-green-600">1.2s</span>
                        <p className="text-xs text-gray-600">excellent</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">
                        {language === 'en' ? 'Success Rate' : 'सफलता दर'}
                      </span>
                      <div className="text-right">
                        <span className="text-2xl font-bold text-purple-600">99.7%</span>
                        <p className="text-xs text-gray-600">uptime</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* System Health Enhanced */}
              <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-0 shadow-xl">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Activity className="w-5 h-5 text-green-600" />
                    <span>{language === 'en' ? 'System Health' : 'सिस्टम स्वास्थ्य'}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">
                        {language === 'en' ? 'Database Status' : 'डेटाबेस स्थिति'}
                      </span>
                      <Badge className="bg-green-600 text-white">
                        {language === 'en' ? 'Optimal' : 'इष्टतम'}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">
                        {language === 'en' ? 'API Health' : 'API स्वास्थ्य'}
                      </span>
                      <Badge className="bg-green-600 text-white">
                        {language === 'en' ? 'Online' : 'ऑनलाइन'}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">
                        {language === 'en' ? 'Security Status' : 'सुरक्षा स्थिति'}
                      </span>
                      <Badge className="bg-blue-600 text-white">
                        {language === 'en' ? 'Secure' : 'सुरक्षित'}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Real-time Stats */}
              <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-0 shadow-xl">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingUp className="w-5 h-5 text-purple-600" />
                    <span>{language === 'en' ? 'Real-time Stats' : 'रियल-टाइम आंकड़े'}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">
                        {language === 'en' ? 'Active Sessions' : 'सक्रिय सत्र'}
                      </span>
                      <div className="text-right">
                        <span className="text-2xl font-bold text-purple-600">1,247</span>
                        <p className="text-xs text-gray-600">current users</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">
                        {language === 'en' ? 'Today\'s Consultations' : 'आज के परामर्श'}
                      </span>
                      <div className="text-right">
                        <span className="text-2xl font-bold text-blue-600">342</span>
                        <p className="text-xs text-gray-600">completed</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">
                        {language === 'en' ? 'New Registrations' : 'नए पंजीकरण'}
                      </span>
                      <div className="text-right">
                        <span className="text-2xl font-bold text-green-600">89</span>
                        <p className="text-xs text-gray-600">today</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminDashboard;