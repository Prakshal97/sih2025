import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../App';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Textarea } from '../components/ui/textarea';
import { Checkbox } from '../components/ui/checkbox';
import { User, Shield, ArrowRight } from 'lucide-react';

const UserOnboarding = () => {
  const { language, addUser } = useAppContext();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    gender: '',
    hometown: '',
    profession: '',
    chronicDisease: '',
    currentMedications: '',
    allergies: '',
    hospitalization: '',
    aadhaarConsent: false
  });

  const questions = {
    en: [
      { key: 'name', label: 'Full Name', type: 'text', required: true },
      { key: 'age', label: 'Age', type: 'number', required: true },
      { key: 'gender', label: 'Gender', type: 'select', options: ['Male', 'Female', 'Other'], required: true },
      { key: 'hometown', label: 'Hometown/City', type: 'text', required: true },
      { key: 'profession', label: 'Profession', type: 'text', required: true },
      { key: 'chronicDisease', label: 'Chronic Disease (if any)', type: 'text', required: false },
      { key: 'currentMedications', label: 'Current Medications', type: 'textarea', required: false },
      { key: 'allergies', label: 'Allergies', type: 'textarea', required: false },
      { key: 'hospitalization', label: 'Recent Hospitalization', type: 'text', required: false }
    ],
    hi: [
      { key: 'name', label: 'पूरा नाम', type: 'text', required: true },
      { key: 'age', label: 'आयु', type: 'number', required: true },
      { key: 'gender', label: 'लिंग', type: 'select', options: ['पुरुष', 'महिला', 'अन्य'], required: true },
      { key: 'hometown', label: 'गृहनगर/शहर', type: 'text', required: true },
      { key: 'profession', label: 'पेशा', type: 'text', required: true },
      { key: 'chronicDisease', label: 'पुरानी बीमारी (यदि कोई हो)', type: 'text', required: false },
      { key: 'currentMedications', label: 'वर्तमान दवाएं', type: 'textarea', required: false },
      { key: 'allergies', label: 'एलर्जी', type: 'textarea', required: false },
      { key: 'hospitalization', label: 'हाल की अस्पताल में भर्ती', type: 'text', required: false }
    ]
  };

  const handleInputChange = (key, value) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  const handleNextStep = () => {
    if (step < questions[language].length) {
      setStep(step + 1);
    } else {
      // Show consent form
      setStep(step + 1);
    }
  };

  const handlePrevStep = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const handleSubmit = () => {
    if (!formData.aadhaarConsent) {
      alert(language === 'en' ? 'Please provide consent to continue' : 'कृपया जारी रखने के लिए सहमति दें');
      return;
    }
    
    addUser(formData);
    navigate('/user-dashboard');
  };

  const currentQuestion = questions[language][step - 1];
  const isConsentStep = step > questions[language].length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 py-8 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-72 h-72 bg-blue-200 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute top-40 right-10 w-72 h-72 bg-purple-200 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse delay-1000"></div>
      </div>

      <div className="container mx-auto px-4 max-w-3xl relative z-10">
        {/* Enhanced Progress Indicator */}
        <div className="mb-10">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-gray-800 to-blue-800 bg-clip-text text-transparent">
                {language === 'en' ? 'Patient Registration' : 'रोगी पंजीकरण'}
              </h1>
              <p className="text-gray-600 mt-2">
                {language === 'en' ? 'Help us create your digital health profile' : 'अपनी डिजिटल स्वास्थ्य प्रोफ़ाइल बनाने में हमारी सहायता करें'}
              </p>
            </div>
            <div className="text-right">
              <div className="text-sm font-medium text-gray-600 mb-1">
                {language === 'en' ? `Step ${step} of ${questions[language].length + 1}` : `चरण ${step} / ${questions[language].length + 1}`}
              </div>
              <div className="text-xs text-gray-500">
                {Math.round((step / (questions[language].length + 1)) * 100)}% Complete
              </div>
            </div>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3 shadow-inner">
            <div 
              className="bg-gradient-to-r from-blue-500 to-indigo-600 h-3 rounded-full transition-all duration-500 shadow-lg"
              style={{ width: `${(step / (questions[language].length + 1)) * 100}%` }}
            ></div>
          </div>
        </div>

        <Card className="shadow-2xl bg-white/95 backdrop-blur-lg border-0">
          <CardHeader className="text-center pb-8 pt-8">
            <div className="flex justify-center mb-6">
              <div className={`w-16 h-16 rounded-2xl flex items-center justify-center shadow-2xl ${!isConsentStep ? 'bg-gradient-to-r from-blue-500 to-indigo-600' : 'bg-gradient-to-r from-green-500 to-emerald-600'}`}>
                {!isConsentStep ? (
                  <User className="w-8 h-8 text-white" />
                ) : (
                  <Shield className="w-8 h-8 text-white" />
                )}
              </div>
            </div>
            <CardTitle className="text-2xl font-bold text-gray-800 mb-2">
              {!isConsentStep ? (
                <span>{language === 'en' ? 'Personal Information' : 'व्यक्तिगत जानकारी'}</span>
              ) : (
                <span>{language === 'en' ? 'Consent & Privacy' : 'सहमति और गोपनीयता'}</span>
              )}
            </CardTitle>
            <p className="text-gray-600">
              {!isConsentStep 
                ? (language === 'en' ? 'Please provide accurate information for better healthcare' : 'बेहतर स्वास्थ्य सेवा के लिए सटीक जानकारी प्रदान करें')
                : (language === 'en' ? 'Your privacy and security are our top priority' : 'आपकी गोपनीयता और सुरक्षा हमारी सर्वोच्च प्राथमिकता है')
              }
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            {!isConsentStep ? (
              <div className="space-y-4">
                <Label htmlFor={currentQuestion.key} className="text-lg font-medium">
                  {currentQuestion.label}
                  {currentQuestion.required && <span className="text-red-500 ml-1">*</span>}
                </Label>
                
                {currentQuestion.type === 'text' && (
                  <Input
                    id={currentQuestion.key}
                    type="text"
                    value={formData[currentQuestion.key]}
                    onChange={(e) => handleInputChange(currentQuestion.key, e.target.value)}
                    className="text-lg p-4"
                    placeholder={`Enter your ${currentQuestion.label.toLowerCase()}`}
                  />
                )}
                
                {currentQuestion.type === 'number' && (
                  <Input
                    id={currentQuestion.key}
                    type="number"
                    value={formData[currentQuestion.key]}
                    onChange={(e) => handleInputChange(currentQuestion.key, e.target.value)}
                    className="text-lg p-4"
                    placeholder={`Enter your ${currentQuestion.label.toLowerCase()}`}
                  />
                )}
                
                {currentQuestion.type === 'select' && (
                  <Select value={formData[currentQuestion.key]} onValueChange={(value) => handleInputChange(currentQuestion.key, value)}>
                    <SelectTrigger className="text-lg p-4">
                      <SelectValue placeholder={`Select ${currentQuestion.label.toLowerCase()}`} />
                    </SelectTrigger>
                    <SelectContent>
                      {currentQuestion.options.map((option) => (
                        <SelectItem key={option} value={option}>
                          {option}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
                
                {currentQuestion.type === 'textarea' && (
                  <Textarea
                    id={currentQuestion.key}
                    value={formData[currentQuestion.key]}
                    onChange={(e) => handleInputChange(currentQuestion.key, e.target.value)}
                    className="text-lg p-4 min-h-[100px]"
                    placeholder={`Enter ${currentQuestion.label.toLowerCase()}`}
                  />
                )}
              </div>
            ) : (
              <div className="space-y-6">
                <div className="bg-blue-50 p-6 rounded-lg">
                  <h3 className="font-semibold text-lg mb-4">
                    {language === 'en' ? 'Data Privacy & Consent' : 'डेटा गोपनीयता और सहमति'}
                  </h3>
                  <p className="text-gray-700 mb-4">
                    {language === 'en' 
                      ? 'By proceeding, you consent to the collection and processing of your health data as per the Digital Personal Data Protection Act, 2023. Your data will be used solely for healthcare purposes.'
                      : 'आगे बढ़कर, आप डिजिटल व्यक्तिगत डेटा संरक्षण अधिनियम, 2023 के अनुसार अपने स्वास्थ्य डेटा के संग्रह और प्रसंस्करण की सहमति देते हैं।'
                    }
                  </p>
                  <div className="flex items-start space-x-3">
                    <Checkbox
                      id="consent"
                      checked={formData.aadhaarConsent}
                      onCheckedChange={(checked) => handleInputChange('aadhaarConsent', checked)}
                      className="mt-1"
                    />
                    <Label htmlFor="consent" className="text-sm">
                      {language === 'en' 
                        ? 'I provide my consent for the collection, processing, and storage of my personal health information for legitimate healthcare purposes.'
                        : 'मैं वैध स्वास्थ्य सेवा उद्देश्यों के लिए अपनी व्यक्तिगत स्वास्थ्य जानकारी के संग्रह, प्रसंस्करण और भंडारण के लिए अपनी सहमति देता हूं।'
                      }
                    </Label>
                  </div>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between pt-6">
              <Button
                variant="outline"
                onClick={handlePrevStep}
                disabled={step === 1}
                className="flex items-center space-x-2"
              >
                <span>{language === 'en' ? 'Previous' : 'पिछला'}</span>
              </Button>
              
              {!isConsentStep ? (
                <Button
                  onClick={handleNextStep}
                  className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700"
                >
                  <span>{language === 'en' ? 'Next' : 'अगला'}</span>
                  <ArrowRight className="w-4 h-4" />
                </Button>
              ) : (
                <Button
                  onClick={handleSubmit}
                  disabled={!formData.aadhaarConsent}
                  className="flex items-center space-x-2 bg-green-600 hover:bg-green-700"
                >
                  <span>{language === 'en' ? 'Complete Registration' : 'पंजीकरण पूरा करें'}</span>
                  <ArrowRight className="w-4 h-4" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default UserOnboarding;