import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Area,
  AreaChart
} from 'recharts';
import { MapPin, TrendingUp, Users, Activity, PieChart, LineChart as LineChartIcon } from 'lucide-react';

const ChartsDemo = () => {
  const { diseases, analytics } = require('../data/mockData').mockData;
  
  // Chart colors
  const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#06B6D4'];
  const GRADIENT_COLORS = {
    primary: '#3B82F6',
    secondary: '#10B981',
    accent: '#F59E0B',
    danger: '#EF4444',
    purple: '#8B5CF6'
  };

  // Disease statistics by state
  const diseaseStats = {};
  diseases.forEach(item => {
    if (!diseaseStats[item.state]) {
      diseaseStats[item.state] = {};
    }
    diseaseStats[item.state][item.disease] = item.cases;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 py-8 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-72 h-72 bg-blue-200 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-72 h-72 bg-purple-200 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse delay-1000"></div>
      </div>

      <div className="container mx-auto px-4 max-w-7xl relative z-10">
        {/* Header */}
        <div className="mb-10">
          <div className="bg-white/70 backdrop-blur-lg rounded-3xl shadow-2xl p-8 border border-white/20">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-gray-800 to-blue-800 bg-clip-text text-transparent mb-2">
              Healthcare Analytics Dashboard
            </h1>
            <p className="text-xl text-gray-600">
              Real-time charts and Kerala state data visualization
            </p>
          </div>
        </div>

        <div className="space-y-8">
          {/* Monthly Trends Chart */}
          <Card className="bg-white/70 backdrop-blur-lg border-0 shadow-2xl">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <LineChartIcon className="w-5 h-5 text-blue-600" />
                <span>Monthly Healthcare Trends</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={analytics.monthlyStats}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="patients" 
                    stroke={GRADIENT_COLORS.primary} 
                    strokeWidth={3}
                    dot={{ fill: GRADIENT_COLORS.primary }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="consultations" 
                    stroke={GRADIENT_COLORS.secondary} 
                    strokeWidth={3}
                    dot={{ fill: GRADIENT_COLORS.secondary }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="receipts" 
                    stroke={GRADIENT_COLORS.accent} 
                    strokeWidth={3}
                    dot={{ fill: GRADIENT_COLORS.accent }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Disease Categories and State Growth */}
          <div className="grid lg:grid-cols-2 gap-8">
            <Card className="bg-white/70 backdrop-blur-lg border-0 shadow-2xl">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <PieChart className="w-5 h-5 text-purple-600" />
                  <span>Disease Categories</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={350}>
                  <RechartsPieChart>
                    <Pie
                      data={analytics.diseaseCategories}
                      cx="50%"
                      cy="50%"
                      outerRadius={120}
                      dataKey="cases"
                      label={({ category, percentage }) => `${category}: ${percentage}%`}
                    >
                      {analytics.diseaseCategories.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </RechartsPieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="bg-white/70 backdrop-blur-lg border-0 shadow-2xl">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5 text-green-600" />
                  <span>Patient Growth by State</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={350}>
                  <AreaChart data={analytics.stateWisePatients}>
                    <defs>
                      <linearGradient id="colorGrowth" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={GRADIENT_COLORS.secondary} stopOpacity={0.8}/>
                        <stop offset="95%" stopColor={GRADIENT_COLORS.secondary} stopOpacity={0.1}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="state" />
                    <YAxis />
                    <Tooltip />
                    <Area 
                      type="monotone" 
                      dataKey="growth" 
                      stroke={GRADIENT_COLORS.secondary} 
                      fillOpacity={1} 
                      fill="url(#colorGrowth)" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Enhanced Disease Distribution with Kerala */}
          <Card className="bg-white/70 backdrop-blur-lg border-0 shadow-2xl">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <MapPin className="w-5 h-5 text-purple-600" />
                <span>Disease Distribution by State (Including Kerala)</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid lg:grid-cols-2 gap-6">
                {Object.entries(diseaseStats).map(([state, diseases]) => (
                  <div key={state} className={`rounded-2xl p-6 ${state === 'Kerala' ? 'bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-200' : 'bg-gradient-to-br from-gray-50 to-blue-50'}`}>
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-bold text-xl text-gray-800">{state}</h4>
                      {state === 'Kerala' && (
                        <Badge className="bg-green-600 text-white">New Data</Badge>
                      )}
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      {Object.entries(diseases).map(([disease, cases]) => (
                        <div key={disease} className="bg-white/80 backdrop-blur-sm rounded-lg p-4 shadow-lg">
                          <div className="text-sm font-medium text-gray-600 mb-1">{disease}</div>
                          <div className="text-2xl font-bold text-blue-600">{cases.toLocaleString()}</div>
                          <div className="text-xs text-gray-500">cases</div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Kerala Special Focus */}
          <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-200 shadow-2xl">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <MapPin className="w-5 h-5 text-green-600" />
                <span className="text-green-800">Kerala Healthcare Analytics</span>
                <Badge className="bg-green-600 text-white">Featured State</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl mx-auto mb-4 flex items-center justify-center">
                    <Users className="w-8 h-8 text-white" />
                  </div>
                  <h4 className="font-bold text-2xl text-gray-800">2,670</h4>
                  <p className="text-green-600 font-medium">Active Patients</p>
                  <p className="text-sm text-gray-600">+22% growth rate</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-2xl mx-auto mb-4 flex items-center justify-center">
                    <Activity className="w-8 h-8 text-white" />
                  </div>
                  <h4 className="font-bold text-2xl text-gray-800">4,950</h4>
                  <p className="text-blue-600 font-medium">Total Cases</p>
                  <p className="text-sm text-gray-600">All disease categories</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-600 rounded-2xl mx-auto mb-4 flex items-center justify-center">
                    <TrendingUp className="w-8 h-8 text-white" />
                  </div>
                  <h4 className="font-bold text-2xl text-gray-800">98.5%</h4>
                  <p className="text-purple-600 font-medium">Recovery Rate</p>
                  <p className="text-sm text-gray-600">Above national average</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ChartsDemo;