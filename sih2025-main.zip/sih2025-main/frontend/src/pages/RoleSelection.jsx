import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../App';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { User, Stethoscope, Settings, ArrowRight, Shield, Heart, Activity, Users } from 'lucide-react';

const RoleSelection = () => {
  const { language, login } = useAppContext();
  const navigate = useNavigate();
  const { translations } = require('../data/mockData').mockData;
  const t = translations[language];

  const roles = [
    {
      key: 'user',
      title: t.patient,
      description: language === 'en' 
        ? 'Access your health records, upload prescriptions, and manage your medical information'
        : 'अपने स्वास्थ्य रिकॉर्ड देखें, प्रिस्क्रिप्शन अपलोड करें और अपनी चिकित्सा जानकारी प्रबंधित करें',
      icon: User,
      gradient: 'from-emerald-400 to-teal-600',
      bgGradient: 'from-emerald-50 to-teal-50',
      iconBg: 'bg-gradient-to-r from-emerald-500 to-teal-600',
      hoverScale: 'hover:scale-105',
      features: ['Digital Health ID', 'Medicine Tracking', 'Consultation History']
    },
    {
      key: 'doctor',
      title: t.doctor,
      description: language === 'en' 
        ? 'Manage patient consultations, view medical histories, and provide prescriptions'
        : 'रोगी परामर्श प्रबंधित करें, चिकित्सा इतिहास देखें और प्रिस्क्रिप्शन प्रदान करें',
      icon: Stethoscope,
      gradient: 'from-blue-400 to-indigo-600',
      bgGradient: 'from-blue-50 to-indigo-50',
      iconBg: 'bg-gradient-to-r from-blue-500 to-indigo-600',
      hoverScale: 'hover:scale-105',
      features: ['Patient Management', 'Medical Records', 'Treatment Plans']
    },
    {
      key: 'admin',
      title: t.admin,
      description: language === 'en' 
        ? 'Access system analytics, manage users and doctors, and view health statistics'
        : 'सिस्टम एनालिटिक्स एक्सेस करें, उपयोगकर्ता और डॉक्टरों का प्रबंधन करें',
      icon: Settings,
      gradient: 'from-purple-400 to-pink-600',
      bgGradient: 'from-purple-50 to-pink-50',
      iconBg: 'bg-gradient-to-r from-purple-500 to-pink-600',
      hoverScale: 'hover:scale-105',
      features: ['System Analytics', 'User Management', 'Health Statistics']
    }
  ];

  const handleRoleSelect = (roleKey) => {
    login(roleKey);
    
    switch (roleKey) {
      case 'user':
        navigate('/user-onboarding');
        break;
      case 'doctor':
        navigate('/doctor-profile');
        break;
      case 'admin':
        navigate('/admin-dashboard');
        break;
      default:
        break;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-72 h-72 bg-blue-200 rounded-full mix-blend-multiply filter blur-xl opacity-30 animate-pulse"></div>
        <div className="absolute top-40 right-10 w-72 h-72 bg-purple-200 rounded-full mix-blend-multiply filter blur-xl opacity-30 animate-pulse delay-1000"></div>
        <div className="absolute -bottom-32 left-1/2 w-72 h-72 bg-pink-200 rounded-full mix-blend-multiply filter blur-xl opacity-30 animate-pulse delay-2000"></div>
      </div>

      <div className="container mx-auto px-4 max-w-7xl relative z-10">
        {/* Hero Section */}
        <div className="text-center pt-20 pb-16">
          <div className="mb-8">
            <div className="flex justify-center mb-6">
              <div className="relative">
                <div className="w-20 h-20 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center shadow-2xl transform rotate-12 hover:rotate-0 transition-transform duration-500">
                  <Heart className="w-10 h-10 text-white" />
                </div>
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full flex items-center justify-center">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                </div>
              </div>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-gray-800 via-blue-800 to-indigo-900 bg-clip-text text-transparent mb-6 leading-tight">
              {language === 'en' ? 'Welcome to Swasth Saathi' : 'स्वास्थ्य साथी में आपका स्वागत है'}
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
              {language === 'en' 
                ? 'Your trusted digital healthcare companion for better health management and well-being'
                : 'बेहतर स्वास्थ्य प्रबंधन और कल्याण के लिए आपका विश्वसनीय डिजिटल स्वास्थ्य साथी'
              }
            </p>
            <div className="flex justify-center items-center space-x-3 mb-8">
              <div className="flex items-center space-x-2 bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg">
                <Shield className="w-4 h-4 text-green-600" />
                <span className="text-sm font-medium text-gray-700">
                  {language === 'en' ? 'Secure & Private' : 'सुरक्षित और निजी'}
                </span>
              </div>
              <div className="flex items-center space-x-2 bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg">
                <Activity className="w-4 h-4 text-blue-600" />
                <span className="text-sm font-medium text-gray-700">
                  {language === 'en' ? 'Real-time Updates' : 'रियल-टाइम अपडेट'}
                </span>
              </div>
              <div className="flex items-center space-x-2 bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg">
                <Users className="w-4 h-4 text-purple-600" />
                <span className="text-sm font-medium text-gray-700">
                  {language === 'en' ? 'Trusted by 10K+' : '10K+ द्वारा भरोसा'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Role Selection */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-4">
            {t.selectRole}
          </h2>
          <p className="text-center text-gray-600 mb-12 text-lg">
            {language === 'en' 
              ? 'Choose your role to access personalized healthcare features'
              : 'व्यक्तिगत स्वास्थ्य सेवा सुविधाओं का उपयोग करने के लिए अपनी भूमिका चुनें'
            }
          </p>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {roles.map((role, index) => {
              const IconComponent = role.icon;
              return (
                <Card 
                  key={role.key} 
                  className={`group cursor-pointer transition-all duration-500 transform ${role.hoverScale} hover:shadow-2xl bg-gradient-to-br ${role.bgGradient} border-0 relative overflow-hidden`}
                  onClick={() => handleRoleSelect(role.key)}
                  style={{
                    animationDelay: `${index * 200}ms`,
                    animation: 'fadeInUp 0.8s ease-out forwards'
                  }}
                >
                  {/* Animated background effect */}
                  <div className={`absolute inset-0 bg-gradient-to-r ${role.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-500`}></div>
                  
                  <CardHeader className="text-center pb-6 pt-8 relative">
                    <div className={`w-20 h-20 mx-auto rounded-2xl ${role.iconBg} flex items-center justify-center mb-6 shadow-2xl group-hover:shadow-3xl transition-all duration-500 group-hover:scale-110`}>
                      <IconComponent className="w-10 h-10 text-white" />
                    </div>
                    <CardTitle className="text-2xl font-bold text-gray-800 mb-3 group-hover:text-gray-900 transition-colors">
                      {role.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-center px-6 pb-8">
                    <CardDescription className="text-gray-600 mb-6 text-base leading-relaxed min-h-[80px] flex items-center">
                      {role.description}
                    </CardDescription>
                    
                    {/* Feature list */}
                    <div className="space-y-2 mb-6">
                      {role.features.map((feature, idx) => (
                        <div key={idx} className="flex items-center justify-center space-x-2 text-sm text-gray-600">
                          <div className={`w-1.5 h-1.5 rounded-full ${role.iconBg}`}></div>
                          <span>{feature}</span>
                        </div>
                      ))}
                    </div>
                    
                    <Button 
                      className={`w-full bg-gradient-to-r ${role.gradient} hover:shadow-lg text-white border-0 py-3 text-base font-semibold transition-all duration-300 group-hover:shadow-xl`}
                      size="lg"
                    >
                      <span>{language === 'en' ? 'Continue as' : 'के रूप में जारी रखें'} {role.title}</span>
                      <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Enhanced Features Preview */}
        <div className="bg-white/70 backdrop-blur-lg rounded-3xl shadow-2xl p-8 mb-16 border border-white/20">
          <h3 className="text-3xl font-bold text-center text-gray-800 mb-8">
            {language === 'en' ? 'Why Choose Swasth Saathi?' : 'स्वास्थ्य साथी क्यों चुनें?'}
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center group">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl mx-auto mb-4 flex items-center justify-center shadow-xl group-hover:scale-110 transition-transform duration-300">
                <User className="w-8 h-8 text-white" />
              </div>
              <h4 className="font-bold text-gray-800 mb-2 text-lg group-hover:text-blue-600 transition-colors">
                {language === 'en' ? 'Digital Health ID' : 'डिजिटल स्वास्थ्य आईडी'}
              </h4>
              <p className="text-gray-600 text-sm leading-relaxed">
                {language === 'en' ? 'Unique identification for seamless healthcare access' : 'निर्बाध स्वास्थ्य सेवा पहुंच के लिए अनूठी पहचान'}
              </p>
            </div>
            <div className="text-center group">
              <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl mx-auto mb-4 flex items-center justify-center shadow-xl group-hover:scale-110 transition-transform duration-300">
                <Stethoscope className="w-8 h-8 text-white" />
              </div>
              <h4 className="font-bold text-gray-800 mb-2 text-lg group-hover:text-green-600 transition-colors">
                {language === 'en' ? 'Expert Consultations' : 'विशेषज्ञ परामर्श'}
              </h4>
              <p className="text-gray-600 text-sm leading-relaxed">
                {language === 'en' ? 'Connect with certified doctors and specialists' : 'प्रमाणित डॉक्टरों और विशेषज्ञों से जुड़ें'}
              </p>
            </div>
            <div className="text-center group">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl mx-auto mb-4 flex items-center justify-center shadow-xl group-hover:scale-110 transition-transform duration-300">
                <Heart className="w-8 h-8 text-white" />
              </div>
              <h4 className="font-bold text-gray-800 mb-2 text-lg group-hover:text-purple-600 transition-colors">
                {language === 'en' ? 'Health Monitoring' : 'स्वास्थ्य निगरानी'}
              </h4>
              <p className="text-gray-600 text-sm leading-relaxed">
                {language === 'en' ? 'Track medications and health progress' : 'दवाओं और स्वास्थ्य प्रगति को ट्रैक करें'}
              </p>
            </div>
            <div className="text-center group">
              <div className="w-16 h-16 bg-gradient-to-r from-orange-500 to-red-500 rounded-2xl mx-auto mb-4 flex items-center justify-center shadow-xl group-hover:scale-110 transition-transform duration-300">
                <Activity className="w-8 h-8 text-white" />
              </div>
              <h4 className="font-bold text-gray-800 mb-2 text-lg group-hover:text-orange-600 transition-colors">
                {language === 'en' ? 'Smart Analytics' : 'स्मार्ट विश्लेषण'}
              </h4>
              <p className="text-gray-600 text-sm leading-relaxed">
                {language === 'en' ? 'AI-powered insights and health trends' : 'AI-संचालित अंतर्दृष्टि और स्वास्थ्य रुझान'}
              </p>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center pb-16">
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-3xl p-8 text-white shadow-2xl">
            <h3 className="text-3xl font-bold mb-4">
              {language === 'en' ? 'Join the Digital Healthcare Revolution' : 'डिजिटल हेल्थकेयर क्रांति में शामिल हों'}
            </h3>
            <p className="text-xl opacity-90 mb-6">
              {language === 'en' 
                ? 'Trusted by healthcare professionals across India'
                : 'भारत भर के स्वास्थ्य पेशेवरों द्वारा विश्वसनीय'
              }
            </p>
            <div className="flex justify-center items-center space-x-8 text-sm">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span>24/7 Available</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                <span>Government Approved</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse"></div>
                <span>HIPAA Compliant</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
};

export default RoleSelection;