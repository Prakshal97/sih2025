import React, { useState } from 'react';
import { useAppContext } from '../App';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Badge } from '../components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { 
  Stethoscope, 
  Users, 
  FileText, 
  TrendingUp, 
  Calendar,
  Plus,
  User,
  Clock
} from 'lucide-react';

const DoctorDashboard = () => {
  const { currentUser, language, users, consultations, setConsultations } = useAppContext();
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedPatient, setSelectedPatient] = useState('');
  const [consultationForm, setConsultationForm] = useState({
    symptoms: '',
    diagnosis: '',
    prescription: ''
  });

  const tabs = {
    en: [
      { key: 'overview', label: 'Overview', icon: TrendingUp },
      { key: 'patients', label: 'Patients', icon: Users },
      { key: 'consultations', label: 'Add Consultation', icon: Plus },
      { key: 'history', label: 'Consultation History', icon: FileText }
    ],
    hi: [
      { key: 'overview', label: 'अवलोकन', icon: TrendingUp },
      { key: 'patients', label: 'मरीज़', icon: Users },
      { key: 'consultations', label: 'परामर्श जोड़ें', icon: Plus },
      { key: 'history', label: 'परामर्श इतिहास', icon: FileText }
    ]
  };

  const handleConsultationSubmit = () => {
    if (!selectedPatient || !consultationForm.symptoms || !consultationForm.diagnosis) {
      alert(language === 'en' ? 'Please fill all required fields' : 'कृपया सभी आवश्यक फ़ील्ड भरें');
      return;
    }

    const newConsultation = {
      id: Date.now(),
      patientId: parseInt(selectedPatient),
      doctorId: currentUser.id,
      date: new Date(),
      symptoms: consultationForm.symptoms,
      diagnosis: consultationForm.diagnosis,
      prescription: consultationForm.prescription,
      status: 'completed'
    };

    setConsultations(prev => [...prev, newConsultation]);
    setConsultationForm({ symptoms: '', diagnosis: '', prescription: '' });
    setSelectedPatient('');
    alert(language === 'en' ? 'Consultation added successfully!' : 'परामर्श सफलतापूर्वक जोड़ा गया!');
  };

  const doctorConsultations = consultations.filter(c => c.doctorId === currentUser?.id);
  const todayConsultations = doctorConsultations.filter(c => 
    new Date(c.date).toDateString() === new Date().toDateString()
  );

  const thisWeekStart = new Date();
  thisWeekStart.setDate(thisWeekStart.getDate() - thisWeekStart.getDay());
  const weekConsultations = doctorConsultations.filter(c => 
    new Date(c.date) >= thisWeekStart
  );

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-6xl">
        {/* Welcome Header */}
        <div className="mb-8">
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-800">
                  {language === 'en' ? 'Doctor Dashboard' : 'डॉक्टर डैशबोर्ड'}
                </h1>
                <p className="text-gray-600 mt-1">
                  {language === 'en' ? 'Welcome' : 'स्वागत है'}, {currentUser?.name}
                </p>
                <div className="flex items-center space-x-4 mt-2">
                  <Badge variant="secondary">
                    {currentUser?.specialty}
                  </Badge>
                  <span className="text-sm text-gray-600">
                    {currentUser?.experience} {language === 'en' ? 'years experience' : 'साल का अनुभव'}
                  </span>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-600">
                  {language === 'en' ? 'Registration No.' : 'पंजीकरण संख्या'}
                </p>
                <p className="font-medium">{currentUser?.registrationNo}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="mb-6">
          <div className="bg-white rounded-lg shadow-sm p-1">
            <div className="flex space-x-1">
              {tabs[language].map((tab) => {
                const IconComponent = tab.icon;
                return (
                  <button
                    key={tab.key}
                    onClick={() => setActiveTab(tab.key)}
                    className={`flex items-center space-x-2 px-4 py-3 rounded-md font-medium transition-colors ${
                      activeTab === tab.key
                        ? 'bg-blue-600 text-white'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <IconComponent className="w-4 h-4" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Tab Content */}
        <div className="space-y-6">
          {activeTab === 'overview' && (
            <div className="grid md:grid-cols-3 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    {language === 'en' ? 'Patients Seen Today' : 'आज देखे गए मरीज़'}
                  </CardTitle>
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{todayConsultations.length}</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    {language === 'en' ? 'This Week' : 'इस सप्ताह'}
                  </CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{weekConsultations.length}</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    {language === 'en' ? 'Total Patients' : 'कुल मरीज़'}
                  </CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{users.length}</div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === 'patients' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Users className="w-5 h-5" />
                  <span>{language === 'en' ? 'Patient List' : 'मरीज़ों की सूची'}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {users.length > 0 ? (
                  <div className="space-y-4">
                    {users.map((patient) => (
                      <div key={patient.id} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                              <User className="w-5 h-5 text-blue-600" />
                            </div>
                            <div>
                              <h3 className="font-medium">{patient.name}</h3>
                              <p className="text-sm text-gray-600">
                                {patient.age} {language === 'en' ? 'years' : 'साल'} • {patient.gender}
                              </p>
                              <p className="text-xs text-gray-500">
                                {language === 'en' ? 'Health ID:' : 'स्वास्थ्य आईडी:'} {patient.healthId}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium">{patient.hometown}</p>
                            {patient.chronicDisease && (
                              <Badge variant="outline" className="text-xs">
                                {patient.chronicDisease}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-gray-600 py-8">
                    {language === 'en' ? 'No patients registered yet' : 'अभी तक कोई मरीज़ पंजीकृत नहीं'}
                  </p>
                )}
              </CardContent>
            </Card>
          )}

          {activeTab === 'consultations' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Plus className="w-5 h-5" />
                  <span>{language === 'en' ? 'Add New Consultation' : 'नया परामर्श जोड़ें'}</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label htmlFor="patientSelect">
                    {language === 'en' ? 'Select Patient' : 'मरीज़ चुनें'} *
                  </Label>
                  <Select value={selectedPatient} onValueChange={setSelectedPatient}>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder={language === 'en' ? 'Choose a patient' : 'एक मरीज़ चुनें'} />
                    </SelectTrigger>
                    <SelectContent>
                      {users.map((patient) => (
                        <SelectItem key={patient.id} value={patient.id.toString()}>
                          {patient.name} - {patient.healthId}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="symptoms">
                    {language === 'en' ? 'Symptoms' : 'लक्षण'} *
                  </Label>
                  <Textarea
                    id="symptoms"
                    value={consultationForm.symptoms}
                    onChange={(e) => setConsultationForm(prev => ({ ...prev, symptoms: e.target.value }))}
                    placeholder={language === 'en' ? 'Describe the patient symptoms...' : 'मरीज़ के लक्षणों का वर्णन करें...'}
                    className="mt-1 min-h-[100px]"
                  />
                </div>

                <div>
                  <Label htmlFor="diagnosis">
                    {language === 'en' ? 'Diagnosis' : 'निदान'} *
                  </Label>
                  <Textarea
                    id="diagnosis"
                    value={consultationForm.diagnosis}
                    onChange={(e) => setConsultationForm(prev => ({ ...prev, diagnosis: e.target.value }))}
                    placeholder={language === 'en' ? 'Enter your diagnosis...' : 'अपना निदान दर्ज करें...'}
                    className="mt-1 min-h-[100px]"
                  />
                </div>

                <div>
                  <Label htmlFor="prescription">
                    {language === 'en' ? 'Prescription & Recommendations' : 'नुस्खे और सिफारिशें'}
                  </Label>
                  <Textarea
                    id="prescription"
                    value={consultationForm.prescription}
                    onChange={(e) => setConsultationForm(prev => ({ ...prev, prescription: e.target.value }))}
                    placeholder={language === 'en' ? 'Medications, dosage, and recommendations...' : 'दवाएं, खुराक और सिफारिशें...'}
                    className="mt-1 min-h-[100px]"
                  />
                </div>

                <Button 
                  onClick={handleConsultationSubmit}
                  className="w-full bg-green-600 hover:bg-green-700"
                  size="lg"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  {language === 'en' ? 'Save Consultation' : 'परामर्श सहेजें'}
                </Button>
              </CardContent>
            </Card>
          )}

          {activeTab === 'history' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <FileText className="w-5 h-5" />
                  <span>{language === 'en' ? 'Consultation History' : 'परामर्श इतिहास'}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {doctorConsultations.length > 0 ? (
                  <div className="space-y-4">
                    {doctorConsultations.map((consultation) => {
                      const patient = users.find(u => u.id === consultation.patientId);
                      return (
                        <div key={consultation.id} className="border rounded-lg p-4">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center space-x-3">
                              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                                <User className="w-4 h-4 text-blue-600" />
                              </div>
                              <div>
                                <h4 className="font-medium">{patient?.name || 'Unknown Patient'}</h4>
                                <p className="text-sm text-gray-600">{patient?.healthId}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="flex items-center space-x-1 text-sm text-gray-600">
                                <Clock className="w-3 h-3" />
                                <span>{new Date(consultation.date).toLocaleDateString()}</span>
                              </div>
                              <Badge variant="secondary" className="text-xs">
                                {consultation.status}
                              </Badge>
                            </div>
                          </div>
                          <div className="space-y-2 text-sm">
                            <div>
                              <span className="font-medium text-gray-700">
                                {language === 'en' ? 'Symptoms:' : 'लक्षण:'}
                              </span>
                              <p className="text-gray-600">{consultation.symptoms}</p>
                            </div>
                            <div>
                              <span className="font-medium text-gray-700">
                                {language === 'en' ? 'Diagnosis:' : 'निदान:'}
                              </span>
                              <p className="text-gray-600">{consultation.diagnosis}</p>
                            </div>
                            <div>
                              <span className="font-medium text-gray-700">
                                {language === 'en' ? 'Prescription:' : 'नुस्खे:'}
                              </span>
                              <p className="text-gray-600">{consultation.prescription}</p>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-center text-gray-600 py-8">
                    {language === 'en' ? 'No consultations recorded yet' : 'अभी तक कोई परामर्श दर्ज नहीं किया गया'}
                  </p>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default DoctorDashboard;