import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../App';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Stethoscope, ArrowRight, User, Award } from 'lucide-react';

const DoctorProfile = () => {
  const { language, addDoctor, doctors } = useAppContext();
  const navigate = useNavigate();
  const [isNewDoctor, setIsNewDoctor] = useState(true);
  const [selectedDoctor, setSelectedDoctor] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    specialty: '',
    experience: '',
    registrationNo: ''
  });

  const specialties = [
    'General Medicine', 'Cardiology', 'Dermatology', 'Orthopedics', 
    'Pediatrics', 'Gynecology', 'Neurology', 'Psychiatry', 'ENT', 'Ophthalmology'
  ];

  const handleInputChange = (key, value) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  const handleExistingDoctorSelect = (doctorId) => {
    const doctor = doctors.find(d => d.id === parseInt(doctorId));
    if (doctor) {
      setSelectedDoctor(doctorId);
      // In a real app, you'd set the current user here
      navigate('/doctor-dashboard');
    }
  };

  const handleSubmit = () => {
    if (!formData.name || !formData.specialty || !formData.experience || !formData.registrationNo) {
      alert(language === 'en' ? 'Please fill all required fields' : 'कृपया सभी आवश्यक फ़ील्ड भरें');
      return;
    }
    
    addDoctor(formData);
    navigate('/doctor-dashboard');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white py-8">
      <div className="container mx-auto px-4 max-w-2xl">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-4">
            {language === 'en' ? 'Doctor Portal' : 'डॉक्टर पोर्टल'}
          </h1>
          <p className="text-gray-600">
            {language === 'en' 
              ? 'Access your medical practice dashboard'
              : 'अपने चिकित्सा अभ्यास डैशबोर्ड तक पहुंचें'
            }
          </p>
        </div>

        {/* Toggle between existing and new doctor */}
        <div className="mb-6">
          <div className="bg-white rounded-lg shadow-sm p-1">
            <div className="flex space-x-1">
              <button
                onClick={() => setIsNewDoctor(false)}
                className={`flex-1 py-3 px-4 rounded-md font-medium transition-colors ${
                  !isNewDoctor
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                {language === 'en' ? 'Existing Doctor' : 'मौजूदा डॉक्टर'}
              </button>
              <button
                onClick={() => setIsNewDoctor(true)}
                className={`flex-1 py-3 px-4 rounded-md font-medium transition-colors ${
                  isNewDoctor
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                {language === 'en' ? 'New Doctor' : 'नया डॉक्टर'}
              </button>
            </div>
          </div>
        </div>

        {!isNewDoctor ? (
          // Existing Doctor Selection
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <User className="w-5 h-5" />
                <span>{language === 'en' ? 'Select Your Profile' : 'अपनी प्रोफाइल चुनें'}</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {doctors.length > 0 ? (
                <div className="space-y-3">
                  {doctors.map((doctor) => (
                    <div 
                      key={doctor.id}
                      className="border rounded-lg p-4 hover:bg-gray-50 cursor-pointer transition-colors"
                      onClick={() => handleExistingDoctorSelect(doctor.id.toString())}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium text-lg">{doctor.name}</h3>
                          <p className="text-gray-600">{doctor.specialty}</p>
                          <p className="text-sm text-gray-500">
                            {doctor.experience} {language === 'en' ? 'years experience' : 'साल का अनुभव'}
                          </p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Award className="w-5 h-5 text-blue-600" />
                          <span className="text-sm text-gray-600">{doctor.registrationNo}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center text-gray-600 py-8">
                  {language === 'en' ? 'No doctors registered yet' : 'अभी तक कोई डॉक्टर पंजीकृत नहीं'}
                </p>
              )}
            </CardContent>
          </Card>
        ) : (
          // New Doctor Registration
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Stethoscope className="w-5 h-5" />
                <span>{language === 'en' ? 'Doctor Registration' : 'डॉक्टर पंजीकरण'}</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="doctorName" className="text-sm font-medium">
                    {language === 'en' ? 'Full Name' : 'पूरा नाम'} *
                  </Label>
                  <Input
                    id="doctorName"
                    type="text"
                    value={formData.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    placeholder={language === 'en' ? 'Dr. John Doe' : 'डॉ. राज कुमार'}
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="specialty" className="text-sm font-medium">
                    {language === 'en' ? 'Medical Specialty' : 'चिकित्सा विशेषता'} *
                  </Label>
                  <Select value={formData.specialty} onValueChange={(value) => handleInputChange('specialty', value)}>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder={language === 'en' ? 'Select specialty' : 'विशेषता चुनें'} />
                    </SelectTrigger>
                    <SelectContent>
                      {specialties.map((specialty) => (
                        <SelectItem key={specialty} value={specialty}>
                          {specialty}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="experience" className="text-sm font-medium">
                    {language === 'en' ? 'Years of Experience' : 'अनुभव के वर्ष'} *
                  </Label>
                  <Input
                    id="experience"
                    type="number"
                    value={formData.experience}
                    onChange={(e) => handleInputChange('experience', e.target.value)}
                    placeholder="15"
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="registrationNo" className="text-sm font-medium">
                    {language === 'en' ? 'Medical Registration Number' : 'चिकित्सा पंजीकरण संख्या'} *
                  </Label>
                  <Input
                    id="registrationNo"
                    type="text"
                    value={formData.registrationNo}
                    onChange={(e) => handleInputChange('registrationNo', e.target.value)}
                    placeholder="MH12345"
                    className="mt-1"
                  />
                </div>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-medium text-blue-800 mb-2">
                  {language === 'en' ? 'Professional Verification' : 'व्यावसायिक सत्यापन'}
                </h4>
                <p className="text-sm text-blue-700">
                  {language === 'en' 
                    ? 'Your medical registration will be verified as per Medical Council regulations.'
                    : 'आपका चिकित्सा पंजीकरण मेडिकल काउंसिल नियमों के अनुसार सत्यापित किया जाएगा।'
                  }
                </p>
              </div>

              <Button 
                onClick={handleSubmit}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3"
                size="lg"
              >
                <span>{language === 'en' ? 'Complete Registration' : 'पंजीकरण पूरा करें'}</span>
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default DoctorProfile;