import React, { useState, createContext, useContext } from "react";
import "./App.css";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import RoleSelection from "./pages/RoleSelection";
import UserOnboarding from "./pages/UserOnboarding";
import UserDashboard from "./pages/UserDashboard";
import DoctorProfile from "./pages/DoctorProfile";
import DoctorDashboard from "./pages/DoctorDashboard";
import AdminDashboard from "./pages/AdminDashboard";
import ChartsDemo from "./pages/ChartsDemo";
import { mockData } from "./data/mockData";

// Context for managing app state
const AppContext = createContext();

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within AppProvider');
  }
  return context;
};

function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [currentRole, setCurrentRole] = useState(null);
  const [language, setLanguage] = useState('en');
  const [users, setUsers] = useState(mockData.users);
  const [doctors, setDoctors] = useState(mockData.doctors);
  const [consultations, setConsultations] = useState(mockData.consultations);
  const [receipts, setReceipts] = useState([]);

  const login = (role, userData = null) => {
    setCurrentRole(role);
    if (userData) {
      setCurrentUser(userData);
    } else if (role === 'admin') {
      // Set a default admin user
      setCurrentUser({
        id: 'admin-1',
        name: 'System Administrator',
        role: 'admin',
        createdAt: new Date()
      });
    }
  };

  const logout = () => {
    setCurrentUser(null);
    setCurrentRole(null);
  };

  const generateHealthId = () => {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const randomNum = Math.floor(Math.random() * 99999).toString().padStart(5, '0');
    return `SS-${year}${month}-${randomNum}`;
  };

  const addUser = (userData) => {
    const healthId = generateHealthId();
    const newUser = { ...userData, id: Date.now(), healthId, createdAt: new Date() };
    setUsers(prev => [...prev, newUser]);
    setCurrentUser(newUser);
  };

  const addDoctor = (doctorData) => {
    const newDoctor = { ...doctorData, id: Date.now(), createdAt: new Date() };
    setDoctors(prev => [...prev, newDoctor]);
    setCurrentUser(newDoctor);
  };

  const appValue = {
    currentUser,
    currentRole,
    language,
    users,
    doctors,
    consultations,
    receipts,
    login,
    logout,
    generateHealthId,
    addUser,
    addDoctor,
    setLanguage,
    setReceipts,
    setConsultations
  };

  return (
    <AppContext.Provider value={appValue}>
      <div className="App min-h-screen bg-slate-50">
        <BrowserRouter>
          <Header />
          <main className="min-h-screen">
            <Routes>
              <Route path="/" element={<RoleSelection />} />
              <Route path="/user-onboarding" element={<UserOnboarding />} />
              <Route path="/user-dashboard" element={
                currentRole === 'user' ? <UserDashboard /> : <Navigate to="/" />
              } />
              <Route path="/doctor-profile" element={<DoctorProfile />} />
              <Route path="/doctor-dashboard" element={
                currentRole === 'doctor' ? <DoctorDashboard /> : <Navigate to="/" />
              } />
              <Route path="/admin-dashboard" element={
                currentRole === 'admin' ? <AdminDashboard /> : <Navigate to="/" />
              } />
              <Route path="/charts-demo" element={<ChartsDemo />} />
            </Routes>
          </main>
          <Footer />
        </BrowserRouter>
      </div>
    </AppContext.Provider>
  );
}

export default App;