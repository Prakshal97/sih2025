import React from 'react';
import { useAppContext } from '../App';
import { Phone, Mail, MapPin, Heart, Shield, Award, Clock } from 'lucide-react';

const Footer = () => {
  const { language } = useAppContext();

  const footerData = {
    en: {
      helpline: "24/7 Medical Helpline",
      email: "Email Support",
      address: "Government of India, Ministry of Health & Family Welfare",
      rights: "All rights reserved",
      madeWith: "Made with",
      forPeople: "for the people of India",
      description: "Empowering India's healthcare system through digital innovation and accessible medical services for all.",
      quickLinks: "Quick Links",
      about: "About Us",
      privacy: "Privacy Policy",
      terms: "Terms of Service",
      accessibility: "Accessibility",
      faq: "FAQ",
      contact: "Contact Us",
      features: "Key Features",
      secure: "100% Secure",
      verified: "Government Verified",
      available: "24/7 Available"
    },
    hi: {
      helpline: "24/7 चिकित्सा हेल्पलाइन",
      email: "ईमेल सहायता",
      address: "भारत सरकार, स्वास्थ्य और परिवार कल्याण मंत्रालय",
      rights: "सभी अधिकार सुरक्षित",
      madeWith: "के साथ बनाया गया",
      forPeople: "भारत के लोगों के लिए",
      description: "डिजिटल नवाचार और सभी के लिए सुलभ चिकित्सा सेवाओं के माध्यम से भारत की स्वास्थ्य सेवा प्रणाली को सशक्त बनाना।",
      quickLinks: "त्वरित लिंक",
      about: "हमारे बारे में",
      privacy: "गोपनीयता नीति",
      terms: "सेवा की शर्तें",
      accessibility: "पहुंच",
      faq: "FAQ",
      contact: "संपर्क करें",
      features: "मुख्य विशेषताएं",
      secure: "100% सुरक्षित",
      verified: "सरकार द्वारा सत्यापित",
      available: "24/7 उपलब्ध"
    }
  };

  const t = footerData[language];

  return (
    <footer className="bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 text-white relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 w-96 h-96 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10"></div>
      </div>

      <div className="container mx-auto px-4 py-12 relative z-10">
        {/* Main Footer Content */}
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          {/* Brand Section */}
          <div className="md:col-span-2 space-y-6">
            <div className="flex items-center space-x-4 mb-6">
              <div className="w-14 h-14 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center shadow-2xl">
                <Heart className="w-8 h-8 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">Swasth Saathi Healthcare</h2>
                <p className="text-blue-200">Your Digital Health Companion</p>
              </div>
            </div>
            <p className="text-gray-300 leading-relaxed max-w-md">
              {t.description}
            </p>
            
            {/* Contact Info */}
            <div className="space-y-4">
              <div className="flex items-center space-x-3 group cursor-pointer">
                <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center group-hover:bg-blue-500/30 transition-colors">
                  <Phone className="w-5 h-5 text-blue-300" />
                </div>
                <div>
                  <p className="font-medium">1075</p>
                  <p className="text-sm text-gray-400">{t.helpline}</p>
                </div>
              </div>
              <div className="flex items-center space-x-3 group cursor-pointer">
                <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center group-hover:bg-green-500/30 transition-colors">
                  <Mail className="w-5 h-5 text-green-300" />
                </div>
                <div>
                  <p className="font-medium">support@swasthsaathi.gov.in</p>
                  <p className="text-sm text-gray-400">{t.email}</p>
                </div>
              </div>
              <div className="flex items-start space-x-3 group cursor-pointer">
                <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center group-hover:bg-purple-500/30 transition-colors">
                  <MapPin className="w-5 h-5 text-purple-300" />
                </div>
                <div>
                  <p className="font-medium">{t.address}</p>
                  <p className="text-sm text-gray-400">New Delhi, India</p>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold mb-4">{t.quickLinks}</h3>
            <ul className="space-y-3">
              {[
                { label: t.about, href: "#" },
                { label: t.privacy, href: "#" },
                { label: t.terms, href: "#" },
                { label: t.accessibility, href: "#" },
                { label: t.faq, href: "#" },
                { label: t.contact, href: "#" }
              ].map((link, index) => (
                <li key={index}>
                  <a 
                    href={link.href} 
                    className="text-gray-300 hover:text-white transition-colors duration-300 flex items-center space-x-2 group"
                  >
                    <div className="w-1 h-1 bg-blue-400 rounded-full group-hover:w-2 transition-all duration-200"></div>
                    <span>{link.label}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Features */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold mb-4">{t.features}</h3>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-green-500/20 rounded-lg flex items-center justify-center">
                  <Shield className="w-4 h-4 text-green-400" />
                </div>
                <span className="text-gray-300">{t.secure}</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-500/20 rounded-lg flex items-center justify-center">
                  <Award className="w-4 h-4 text-blue-400" />
                </div>
                <span className="text-gray-300">{t.verified}</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-purple-500/20 rounded-lg flex items-center justify-center">
                  <Clock className="w-4 h-4 text-purple-400" />
                </div>
                <span className="text-gray-300">{t.available}</span>
              </div>
            </div>

            {/* Government Badges */}
            <div className="space-y-3">
              <div className="bg-gradient-to-r from-blue-500/10 to-indigo-500/10 border border-blue-500/20 rounded-lg p-3">
                <p className="text-sm font-medium text-blue-300">Digital India Initiative</p>
                <p className="text-xs text-gray-400">Certified Healthcare Platform</p>
              </div>
              <div className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 border border-green-500/20 rounded-lg p-3">
                <p className="text-sm font-medium text-green-300">HIPAA Compliant</p>
                <p className="text-xs text-gray-400">Secure Health Data Protection</p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-700 pt-8">
          <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
            <div className="flex items-center space-x-2 text-gray-300">
              <span>© 2024 Swasth Saathi Healthcare.</span>
              <span>{t.rights}</span>
            </div>
            
            <div className="flex items-center space-x-2 text-gray-300">
              <span>{t.madeWith}</span>
              <Heart className="w-4 h-4 text-red-400 animate-pulse" />
              <span>{t.forPeople}</span>
            </div>

            {/* Social Trust Indicators */}
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-1 bg-green-500/10 px-3 py-1 rounded-full">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-xs text-green-300">System Online</span>
              </div>
              <div className="flex items-center space-x-1 bg-blue-500/10 px-3 py-1 rounded-full">
                <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                <span className="text-xs text-blue-300">Secure Connection</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;