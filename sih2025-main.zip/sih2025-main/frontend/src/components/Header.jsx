import React from 'react';
import { useAppContext } from '../App';
import { Button } from './ui/button';
import { LogOut, Globe, Heart, Bell } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Header = () => {
  const { currentUser, currentRole, language, setLanguage, logout } = useAppContext();
  const navigate = useNavigate();
  const { translations } = require('../data/mockData').mockData;
  const t = translations[language];

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'hi' : 'en');
  };

  return (
    <header className="bg-white/95 backdrop-blur-lg border-b border-blue-100 shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo and App Name */}
          <div className="flex items-center space-x-4 cursor-pointer" onClick={() => navigate('/')}>
            <div className="relative group">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center shadow-xl group-hover:shadow-2xl transition-all duration-300 group-hover:scale-105">
                <Heart className="w-7 h-7 text-white group-hover:animate-pulse" />
              </div>
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full flex items-center justify-center">
                <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse"></div>
              </div>
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-gray-800 to-blue-800 bg-clip-text text-transparent">
                {t.appName}
              </h1>
              <p className="text-sm text-gray-600 font-medium">{t.tagline}</p>
            </div>
          </div>

          {/* Navigation and Controls */}
          <div className="flex items-center space-x-4">
            {/* Language Toggle */}
            <Button 
              variant="outline" 
              size="sm" 
              onClick={toggleLanguage}
              className="flex items-center space-x-2 hover:bg-blue-50 border-blue-200 hover:border-blue-300 transition-all duration-300"
              aria-label="Toggle Language"
            >
              <Globe className="w-4 h-4 text-blue-600" />
              <span className="font-medium text-blue-700">
                {language === 'en' ? 'हिं' : 'EN'}
              </span>
            </Button>

            {/* User Info and Controls */}
            {currentUser && (
              <div className="flex items-center space-x-4">
                {/* Notification Bell */}
                <Button 
                  variant="ghost" 
                  size="sm"
                  className="relative hover:bg-blue-50 transition-colors duration-300"
                >
                  <Bell className="w-4 h-4 text-gray-600" />
                  <div className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                </Button>

                {/* User Profile */}
                <div className="flex items-center space-x-3 bg-gradient-to-r from-blue-50 to-indigo-50 px-4 py-2 rounded-full border border-blue-100">
                  <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-bold">
                      {currentUser.name?.charAt(0) || 'U'}
                    </span>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-gray-800 max-w-32 truncate">
                      {currentUser.name}
                    </p>
                    <p className="text-xs text-gray-600 capitalize bg-blue-100 px-2 py-0.5 rounded-full">
                      {currentRole}
                    </p>
                  </div>
                </div>

                {/* Logout Button */}
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleLogout}
                  className="flex items-center space-x-2 hover:bg-red-50 border-red-200 hover:border-red-300 transition-all duration-300"
                  aria-label="Logout"
                >
                  <LogOut className="w-4 h-4 text-red-600" />
                  <span className="text-red-700 font-medium">{t.logout}</span>
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;