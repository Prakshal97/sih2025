export const mockData = {
  users: [
    {
      id: 1,
      name: "राज कुमार",
      age: 45,
      gender: "Male",
      hometown: "Delhi",
      profession: "Teacher",
      chronicDisease: "Diabetes",
      currentMedications: "Metformin",
      allergies: "None",
      hospitalization: "No",
      aadhaarConsent: true,
      healthId: "SS-202409-12345",
      createdAt: new Date('2024-09-01')
    },
    {
      id: 2,
      name: "प्रिया शर्मा",
      age: 32,
      gender: "Female",
      hometown: "Mumbai",
      profession: "Software Engineer",
      chronicDisease: "Hypertension",
      currentMedications: "Amlodipine",
      allergies: "Penicillin",
      hospitalization: "Yes - 2023",
      aadhaarConsent: true,
      healthId: "SS-202409-12346",
      createdAt: new Date('2024-09-02')
    }
  ],
  
  doctors: [
    {
      id: 1,
      name: "Dr. अमित गुप्ता",
      specialty: "Cardiology",
      experience: 15,
      registrationNo: "MH12345",
      createdAt: new Date('2024-08-15')
    },
    {
      id: 2,
      name: "Dr. सुनीता पटेल",
      specialty: "General Medicine",
      experience: 12,
      registrationNo: "DL67890",
      createdAt: new Date('2024-08-20')
    }
  ],

  consultations: [
    {
      id: 1,
      patientId: 1,
      doctorId: 1,
      date: new Date('2024-09-15'),
      symptoms: "Chest pain, shortness of breath",
      diagnosis: "Mild angina",
      prescription: "Rest, follow up in 1 week",
      status: "completed"
    },
    {
      id: 2,
      patientId: 2,
      doctorId: 2,
      date: new Date('2024-09-20'),
      symptoms: "Headache, dizziness",
      diagnosis: "High blood pressure",
      prescription: "Continue current medication, lifestyle changes",
      status: "completed"
    }
  ],

  diseases: [
    { state: "Delhi", disease: "Diabetes", cases: 1500 },
    { state: "Delhi", disease: "Hypertension", cases: 2100 },
    { state: "Delhi", disease: "Heart Disease", cases: 800 },
    { state: "Delhi", disease: "Respiratory", cases: 950 },
    { state: "Mumbai", disease: "Diabetes", cases: 2200 },
    { state: "Mumbai", disease: "Hypertension", cases: 3100 },
    { state: "Mumbai", disease: "Respiratory", cases: 1200 },
    { state: "Mumbai", disease: "Heart Disease", cases: 1100 },
    { state: "Bangalore", disease: "Diabetes", cases: 1800 },
    { state: "Bangalore", disease: "Hypertension", cases: 2500 },
    { state: "Bangalore", disease: "Heart Disease", cases: 750 },
    { state: "Bangalore", disease: "Respiratory", cases: 680 },
    { state: "Chennai", disease: "Heart Disease", cases: 900 },
    { state: "Chennai", disease: "Diabetes", cases: 1600 },
    { state: "Chennai", disease: "Hypertension", cases: 2200 },
    { state: "Chennai", disease: "Respiratory", cases: 720 },
    { state: "Kerala", disease: "Diabetes", cases: 1350 },
    { state: "Kerala", disease: "Hypertension", cases: 1900 },
    { state: "Kerala", disease: "Heart Disease", cases: 650 },
    { state: "Kerala", disease: "Respiratory", cases: 580 },
    { state: "Kerala", disease: "Dengue", cases: 340 },
    { state: "Kerala", disease: "Malaria", cases: 120 }
  ],

  analytics: {
    totalPatients: 15420,
    totalDoctors: 890,
    totalConsultations: 12350,
    receiptsUploaded: 8760,
    monthlyStats: [
      { month: 'Jan', patients: 1200, consultations: 980, receipts: 650 },
      { month: 'Feb', patients: 1350, consultations: 1100, receipts: 720 },
      { month: 'Mar', patients: 1450, consultations: 1250, receipts: 890 },
      { month: 'Apr', patients: 1600, consultations: 1320, receipts: 950 },
      { month: 'May', patients: 1520, consultations: 1280, receipts: 870 },
      { month: 'Jun', patients: 1380, consultations: 1150, receipts: 780 },
      { month: 'Jul', patients: 1280, consultations: 1050, receipts: 720 },
      { month: 'Aug', patients: 1150, consultations: 950, receipts: 680 },
      { month: 'Sep', patients: 1320, consultations: 1080, receipts: 750 }
    ],
    stateWisePatients: [
      { state: 'Delhi', patients: 3200, growth: 12 },
      { state: 'Mumbai', patients: 4100, growth: 18 },
      { state: 'Bangalore', patients: 2800, growth: 15 },
      { state: 'Chennai', patients: 2650, growth: 10 },
      { state: 'Kerala', patients: 2670, growth: 22 }
    ],
    ageDistribution: [
      { ageGroup: '0-18', patients: 2340, percentage: 15 },
      { ageGroup: '19-35', patients: 4620, percentage: 30 },
      { ageGroup: '36-50', patients: 4310, percentage: 28 },
      { ageGroup: '51-65', patients: 2770, percentage: 18 },
      { ageGroup: '65+', patients: 1380, percentage: 9 }
    ],
    diseaseCategories: [
      { category: 'Diabetes', cases: 8450, percentage: 22 },
      { category: 'Hypertension', cases: 11800, percentage: 31 },
      { category: 'Heart Disease', cases: 4200, percentage: 11 },
      { category: 'Respiratory', cases: 4130, percentage: 11 },
      { category: 'Others', cases: 9420, percentage: 25 }
    ]
  },

  translations: {
    en: {
      appName: "Swasth Saathi Healthcare",
      tagline: "Your Digital Health Companion",
      selectRole: "Select Your Role",
      patient: "Patient",
      doctor: "Doctor",
      admin: "Admin",
      login: "Login",
      dashboard: "Dashboard",
      profile: "Profile",
      logout: "Logout",
      healthId: "Health ID",
      uploadReceipt: "Upload Medicine Receipt",
      addMedicine: "Add Medicine Manually",
      consultations: "Consultations",
      patients: "Patients",
      analytics: "Analytics"
    },
    hi: {
      appName: "स्वास्थ्य साथी हेल्थकेयर",
      tagline: "आपका डिजिटल स्वास्थ्य साथी",
      selectRole: "अपनी भूमिका चुनें",
      patient: "मरीज़",
      doctor: "डॉक्टर",
      admin: "प्रशासक",
      login: "लॉगिन",
      dashboard: "डैशबोर्ड",
      profile: "प्रोफाइल",
      logout: "लॉगआउट",
      healthId: "स्वास्थ्य आईडी",
      uploadReceipt: "दवा की रसीद अपलोड करें",
      addMedicine: "मैन्युअल रूप से दवा जोड़ें",
      consultations: "परामर्श",
      patients: "मरीज़",
      analytics: "विश्लेषण"
    }
  }
};